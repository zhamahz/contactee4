<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>VUZ.KG</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
          rel="stylesheet">

    <!-- Vendor CSS Files -->
    <!-- Link Datatable-->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>

    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/rowgroup/1.1.2/css/rowGroup.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
          href="https://cdn.datatables.net/buttons/1.6.1/css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
          href="https://cdn.datatables.net/datetime/1.0.2/css/dataTables.dateTime.min.css">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">
    <link href="assets/css/new_styles.css" rel="stylesheet">
</head>

<body>

<!-- ======= Header ======= -->
<header id="header" class="fixed-top d-flex align-items-center">
    <div class="container">
        <div class="header-container d-flex align-items-center justify-content-between">
            <div class="logo">
                <h1 class="text-light"><a href="index.php"><span>VUZ.KG</span></a></h1>
            </div>
            <nav id="navbar" class="navbar">
                <ul>
                    <li><a href="#hero">Главная</a></li>
                    <li><a href="#about">О нас</a></li>
                    <li><a href="#why-us">Образование</a></li>
                    <li><a href="#portfolio ">Университеты</a></li>
                    <li class="dropdown"><a href="#services"><span>Разделы</span> <i class="bi bi-chevron-down"></i></a>
                        <ul>
                            <li><a href="#">Поступление</a></li>
                            <li><a href="#">Стипендии</a></li>
                            <li><a href="#">Курсы</a></li>
                            <li><a href="#">Виза</a></li>
                        </ul>
                    </li>
                    <li><a class="getstarted scrollto" href="#">Войти</a></li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav><!-- .navbar -->
        </div><!-- End Header Container -->
    </div>
</header><!-- End Header -->

<style>
    #hero {
        width: 100%;
        height: 80vh;
        background: url("assets/img/background.jpg") center center;
        background-size: cover;
        position: relative;
    }

</style>
<!-- ======= Hero Section ======= -->
<section id="hero" class=" hero d-flex align-items-center">
    <div class="container text-center position-relative" data-aos="fade-in" data-aos-delay="200">
        <h1>ОБРАЗОВАНИЕ В КЫРГЫЗСТАНЕ С VUZ.KG</h1>
        <h2>Мы поможем Вам поступить в любой ВУЗ Кыргызстана!</h2>
        <a href="#about" class="cta-btn scrollto">Помощь в поступлении</a>
    </div>
</section><!-- End Hero -->

<main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container">
            <div class="row content">
                <div class="col-lg-7" data-aos="fade-right" data-aos-delay="100">
                    <h2>Образование и коронавирус</h2>
                    <p align="justify">Несмотря на ситуацию с коронавирусом поступления на программы среднего и
                        высшего образования за рубежом продолжаются. Приемные комиссии работают в штатном режиме.
                        Открыт набор студентов на
                        зимний интейк, а также осень 2021 года. Будем держать вас в курсе.</p>
                </div>
                <div class="col-lg-5 pt-4 pt-lg-0" data-aos="fade-left" data-aos-delay="200">
                    <h2> Что мы делаем?</h2>
                    <ul>
                        <li><i class="ri-check-double-line"></i> Подбор программ по вашим критериям</li>
                        <li><i class="ri-check-double-line"></i> Подготовка аппликационных документов</li>
                        <li><i class="ri-check-double-line"></i> Взаимодействие с вузами по любым вопросам</li>
                        <li><i class="ri-check-double-line"></i> Получение приглашения из ВУЗа</li>
                        <li><i class="ri-check-double-line"></i> Оформление студенческой визы</li>
                    </ul>
                </div>
            </div>
        </div>
    </section><!-- End About Section -->

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
        <div class="container">

            <div class="row counters">

                <div class="col-lg-3 col-6 text-center">
                    <span data-purecounter-start="0" data-purecounter-end="232" data-purecounter-duration="1"
                          class="purecounter"></span>
                    <p>Стран</p>
                </div>

                <div class="col-lg-3 col-6 text-center">
                    <span data-purecounter-start="0" data-purecounter-end="521" data-purecounter-duration="1"
                          class="purecounter"></span>
                    <p>Направлений</p>
                </div>

                <div class="col-lg-3 col-6 text-center">
                    <span data-purecounter-start="0" data-purecounter-end="50" data-purecounter-duration="1"
                          class="purecounter"></span>
                    <p>Университетов</p>
                </div>

                <div class="col-lg-3 col-6 text-center">
                    <span data-purecounter-start="0" data-purecounter-end="1500" data-purecounter-duration="1"
                          class="purecounter"></span>
                    <p>Посещений в месяц</p>
                </div>

            </div>

        </div>
    </section><!-- End Counts Section -->

    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us">
        <div class="container">

            <div class="row">
                <div class="col-lg-4 d-flex align-items-stretch" data-aos="fade-right">
                    <div class="content">
                        <h3>Образование в КР</h3>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt ut
                            labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit
                            Asperiores dolores sed et. Tenetur quia eos. Autem tempore quibusdam vel necessitatibus
                            optio ad corporis.
                        </p>
                        <div class="text-center">
                            <a href="#" class="more-btn">Learn More <i class="bx bx-chevron-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 d-flex align-items-stretch">
                    <div class="icon-boxes d-flex flex-column justify-content-center">
                        <div class="row">
                            <div class="col-xl-4 d-flex align-items-stretch" data-aos="zoom-in"
                                 data-aos-delay="100">
                                <div class="icon-box mt-4 mt-xl-0">
                                    <i class="bx bx-receipt"></i>
                                    <h4>Бакалавр</h4>
                                    <p>Consequuntur sunt aut quasi enim aliquam quae harum pariatur laboris nisi ut
                                        aliquip</p>
                                    <a href="#" class="more-btn">Learn More</a>
                                </div>
                            </div>
                            <div class="col-xl-4 d-flex align-items-stretch" data-aos="zoom-in"
                                 data-aos-delay="200">
                                <div class="icon-box mt-4 mt-xl-0">
                                    <i class="bx bx-cube-alt"></i>
                                    <h4>Магистратура</h4>
                                    <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                                        deserunt</p>
                                    <a href="#" class="more-btn">Learn More</a>
                                </div>
                            </div>
                            <div class="col-xl-4 d-flex align-items-stretch" data-aos="zoom-in"
                                 data-aos-delay="300">
                                <div class="icon-box mt-4 mt-xl-0">
                                    <i class="bx bx-images"></i>
                                    <h4>Аспирантура</h4>
                                    <p>Aut suscipit aut cum nemo deleniti aut omnis. Doloribus ut maiores omnis
                                        facere</p>
                                    <a href="#" class="more-btn">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div><!-- End .content-->
                </div>
            </div>
        </div>
    </section><!-- End Why Us Section -->

    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
        <div class="container">

            <div class="text-center" data-aos="zoom-in">
                <h1>Почему стоит обратиться в VUZ.KG?</h1><br>
                <p> Наша главная задача – это Ваш успех в поступлении.</p>
                <p>Мы помогаем осуществить Вашу мечту и достигнуть поставленной цели.</p>
                <a class="cta-btn" href="applicant/apply.php">Подать заявку</a>
            </div>

        </div>
    </section><!-- End Cta Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
        <div class="container">
            <div class="section-title" data-aos="fade-left">
                <h2>Университеты</h2>
                <p>Информация носит ознакомительный характер. Для получения точной информации обратитесь к
                    официальному
                    сайту учебного заведения.</p>
            </div>
            <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

                <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                    <div class="portfolio-wrap">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/BHU_fantan.jpg/1280px-BHU_fantan.jpg"
                             class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4>Бишкекский гуманитарный университет имени К. Карасаева</h4>
                            <div class="portfolio-links">
                                <a href="https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/BHU_fantan.jpg/1280px-BHU_fantan.jpg"
                                   data-gallery="portfolioGallery"
                                   class="portfolio-lightbox" title="App 1"><i class="bx bx-plus"></i></a>
                                <a href="https://kaktus.media/doc/375582_gid_po_vyzam_bishkeka:_bishkekskiy_gymanitarnyy_yniversitet.html"
                                   title="More Details"><i class="bx bx-link"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-web">
                    <div class="portfolio-wrap">
                        <img src="https://smapse.ru/storage/2020/05/kyrgyz-national-university-smapse8.jpg"
                             class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4>Кыргызский национальный университет им. Ж. Баласагына</h4>
                            <div class="portfolio-links">
                                <a href="https://smapse.ru/storage/2020/05/kyrgyz-national-university-smapse8.jpg"
                                   data-gallery="portfolioGallery"
                                   class="portfolio-lightbox" title="Web 3"><i class="bx bx-plus"></i></a>
                                <a href="https://kaktus.media/doc/375542_gid_po_vyzam_bishkeka:_kyrgyzskiy_nacionalnyy_yniversitet.html"
                                   title="More Details"><i class="bx bx-link"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                    <div class="portfolio-wrap">
                        <img src="https://kstu.kg/fileadmin/main_menu/enrollee/fasad.jpg" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4>Кыргызский государственный технический университет им. И. Раззакова</h4>
                            <div class="portfolio-links">
                                <a href="https://kstu.kg/fileadmin/main_menu/enrollee/fasad.jpg"
                                   data-gallery="portfolioGallery"
                                   class="portfolio-lightbox" title="App 2"><i class="bx bx-plus"></i></a>
                                <a href="https://kaktus.media/doc/375836_gid_po_vyzam_bishkeka:_kyrgyzskiy_gosydarstvennyy_tehnicheskiy_yniversitet_kgty.html"
                                   title="More Details"><i class="bx bx-link"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-card">
                    <div class="portfolio-wrap">
                        <img src="https://data.kaktus.media/image/original/2018-06-25_09-49-12_985764.jpg"
                             class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4>Кыргызский государственный университет строительства, транспорта и архитектуры</h4>
                            <div class="portfolio-links">
                                <a href="https://data.kaktus.media/image/original/2018-06-25_09-49-12_985764.jpg"
                                   data-gallery="portfolioGallery"
                                   class="portfolio-lightbox" title="Card 2"><i class="bx bx-plus"></i></a>
                                <a href="https://kaktus.media/doc/376201_gid_po_vyzam_bishkeka:_kgysta.html"
                                   title="More Details"><i class="bx bx-link"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-web">
                    <div class="portfolio-wrap">
                        <img src="https://data.kaktus.media/image/original/2020-07-13_10-29-54_502281.jpg"
                             class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4>УНПК Международный университет Кыргызстана;</h4>
                            <div class="portfolio-links">
                                <a href="https://data.kaktus.media/image/original/2020-07-13_10-29-54_502281.jpg"
                                   data-gallery="portfolioGallery"
                                   class="portfolio-lightbox" title="Web 2"><i class="bx bx-plus"></i></a>
                                <a href="https://kaktus.media/doc/376033_gid_po_vyzam_bishkeka:_mejdynarodnyy_yniversitet_kyrgyzstana_myk.html"
                                   title="More Details"><i class="bx bx-link"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                    <div class="portfolio-wrap">
                        <img src="https://i1.photo.2gis.com/images/branch/112/15762598744810430_9173.jpg"
                             class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4>Кыргызская государственная медицинская академия имени И. К. Ахунбаева</h4>
                            <div class="portfolio-links">
                                <a href="https://i1.photo.2gis.com/images/branch/112/15762598744810430_9173.jpg"
                                   data-gallery="portfolioGallery"
                                   class="portfolio-lightbox" title="App 3"><i class="bx bx-plus"></i></a>
                                <a href="https://kaktus.media/doc/394190_gid_po_vyzam:_kyrgyzskaia_gosydarstvennaia_medicinskaia_akademiia_imeni_i.k._ahynbaeva_kgma.html   "
                                   title="More Details"><i class="bx bx-link"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <a href="uni_list.php" class="d-flex align-items-center justify-content-center"><i
                        style="font-size: 40px;" class="bi bi-arrow-right"></i></a>
        </div>
    </section><!-- End Portfolio Section -->
    <!-- ======= Services Section ======= -->

    <section id="services" class="services section-bg">
        <div class="container">

            <div class="row">
                <div class="col-lg-4">
                    <div class="section-title" data-aos="fade-right">
                        <h2>Разное</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. At expedita magni minus optio.
                            At
                            consequatur dolorum earum labore quia.</p>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-md-6 align-items-stretch">
                            <div class="icon-box" data-aos="zoom-in" data-aos-delay="100">
                                <div class="icon"><i class="bx bi-window-dock"></i></div>
                                <h4><a href="">Поступление</a></h4>
                                <p>Пошаговая инструкция по поступлению в ВУЗ</p>
                            </div>
                        </div>

                        <div class="col-md-6 align-items-stretch mt-4 mt-lg-0">
                            <div class="icon-box" data-aos="zoom-in" data-aos-delay="200">
                                <div class="icon"><i class="bx bi-cash-stack"></i></div>
                                <h4><a href="">Стипендии</a></h4>
                                <p>Как получить грант или стипендию на обучение?</p>
                            </div>
                        </div>

                        <div class="col-md-6 align-items-stretch mt-4">
                            <div class="icon-box" data-aos="zoom-in" data-aos-delay="300">
                                <div class="icon"><i class="bx bx-book-open"></i></div>
                                <h4><a href="">Языковые курсы</a></h4>
                                <p>Где проходить курсы в КР?</p>
                            </div>
                        </div>

                        <div class="col-md-6 align-items-stretch mt-4">
                            <div class="icon-box" data-aos="zoom-in" data-aos-delay="400">
                                <div class="icon"><i class="bx bx-world"></i></div>
                                <h4><a href="">Виза</a></h4>
                                <p>Сроки и стоимость оформления студенческих виз</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </section><!-- End Services Section -->

</main><!-- End #main -->
<footer id="footer">

    <div class="container d-md-flex py-4">

        <div class="me-md-auto text-center text-md-start">
            <div class="copyright">
                &copy; Copyright <strong><span>VUZ.KG</span></strong>. All Rights Reserved
            </div>
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
            <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
            <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
            <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
            <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
            <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
    </div>
</footer><!-- End Footer -->

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<script src="assets/vendor/purecounter/purecounter.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

<script src="assets/js/main.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>

<script src="assets/vendor/datatables/js/dataTables.bootstrap4.min.js"></script>

<script src="assets/vendor/datatables/js/buttons.bootstrap4.min.js"></script>
<script src="assets/vendor/datatables/js/data-table.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/rowgroup/1.0.4/js/dataTables.rowGroup.min.js"></script>
<script src="https://cdn.datatables.net/select/1.2.7/js/dataTables.select.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.5/js/dataTables.fixedHeader.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>


</body>

</html>
