<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>VUZ.KG</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
          rel="stylesheet">

    <!-- Vendor CSS Files -->
    <!-- Link Datatable-->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>

    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/datetime/1.0.2/css/dataTables.dateTime.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/rowgroup/1.1.2/css/rowGroup.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
          href="https://cdn.datatables.net/buttons/1.6.1/css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
          href="https://cdn.datatables.net/datetime/1.0.2/css/dataTables.dateTime.min.css">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">
</head>

<body>

<!-- ======= Header ======= -->
<header id="header" class="fixed-top d-flex align-items-center">
    <div class="container">
        <div class="header-container d-flex align-items-center justify-content-between">
            <div class="logo">
                <h1 class="text-light"><a href="index.php"><span>VUZ.KG</span></a></h1>
            </div>
            <nav id="navbar" class="navbar">
                <ul>
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="#about">О нас</a></li>
                    <li><a href="#why_us">Образование</a></li>
                    <li><a href="#portfolio ">Университеты</a></li>
                    <li class="dropdown"><a href="#services"><span>Разделы</span> <i class="bi bi-chevron-down"></i></a>
                        <ul>
                            <li><a href="#">Поступление</a></li>
                            <li><a href="#">Стипендии</a></li>
                            <li><a href="#">Курсы</a></li>
                            <li><a href="#">Виза</a></li>
                        </ul>
                    </li>
                    <li><a class="getstarted scrollto" href="#">Войти</a></li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav><!-- .navbar -->
        </div><!-- End Header Container -->
    </div>
</header><!-- End Header -->

<main id="main">
    <section class="nav-title">
        <div class="header-h1 container">
            <h1>Cтатус ВУЗов Кыргызстана</h1>
        </div>
    </section>

    <!-- ======= Portfolio Details Section ======= -->
    <section id="apply" class="portfolio-details">
        <div class="container"><h2>Государственные вузы</h2>
            <p>
            <ul class="bb-list bb-list-1">
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/375542_gid_po_vyzam_bishkeka:_kyrgyzskiy_nacionalnyy_yniversitet.html"
                       target="_blank">Кыргызский национальный университет им. Ж. Баласагына</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/375836_gid_po_vyzam_bishkeka:_kyrgyzskiy_gosydarstvennyy_tehnicheskiy_yniversitet_kgty.html"
                       target="_blank">Кыргызский государственный технический университет им. И. Раззакова</a>
                </li>
                <li><a class="bb-link" href="https://kaktus.media/doc/376201_gid_po_vyzam_bishkeka:_kgysta.html"
                       target="_blank">Кыргызский
                        государственный университет строительства, транспорта и архитектуры</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/375582_gid_po_vyzam_bishkeka:_bishkekskiy_gymanitarnyy_yniversitet.html"
                       target="_blank">Бишкекский гуманитарный университет им. К. Карасаева (БГУ)</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376006_gid_po_vyzam_bishkeka:_kyrgyzskaia_gosydarstvennaia_akademiia_fizicheskoy_kyltyry_i_sporta.html"
                       target="_blank">Кыргызская государственная академия физической культуры и спорта</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376497_gid_po_vyzam_bishkeka:_kyrgyzskaia_gosydarstvennaia_uridicheskaia_akademiia_kgua.html"
                       target="_blank">Кыргызская государственная юридическая академия</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376534_gid_po_vyzam_bishkeka:_kyrgyzskiy_nacionalnyy_agrarnyy_yniversitet_im._skriabina_knay.html"
                       target="_blank">Кыргызский национальный аграрный университет им. К. И. Скрябина</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376033_gid_po_vyzam_bishkeka:_mejdynarodnyy_yniversitet_kyrgyzstana_myk.html"
                       target="_blank">УНПК Международный университет Кыргызстана</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376438_gid_po_vyzam_bishkeka:_akademiia_mvd_kyrgyzskoy_respybliki.html"
                       target="_blank">Академия МВД КР им. генерал-майора милиции Э. А. Алиева</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376362_gid_po_vyzam_bishkeka:_kyrgyzskiy_gosydarstvennyy_yniversitet_kyltyry_i_iskysstv.html"
                       target="_blank">Кыргызский государственный университет искусств им. Б. Бейшеналиевой</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376047_gid_po_vyzam:_kyrgyzskaia_nacionalnaia_konservatoriia_imeni_k._moldobasanova_knk.html"
                       target="_blank">Кыргызская национальная консерватория</a>
                </li>
                <li><a class="bb-link" href="" target="_blank">Кыргызско-турецкий университет "Манас"</a></li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/375986_gid_po_vyzam_bishkeka:_nacionalnaia_akademiia_hydojestv_kyrgyzskoy_respybliki.html"
                       target="_blank">Национальная академия художеств КР имени Т. Садыкова</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/375060_gid_po_vyzam_bishkeka:_kyrgyzsko_rossiyskiy_slavianskiy_yniversitet.html"
                       target="_blank">Кыргызско-Российский Славянский университет им. Б. Ельцина</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376562_gid_po_vyzam_bishkeka:_kyrgyzskiy_ekonomicheskiy_yniversitet_imeni_mysy_ryskylbekova_key.html"
                       target="_blank">Кыргызский экономический университет</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376295_gid_po_vyzam_bishkeka:_instityt_socialnogo_razvitiia_i_predprinimatelstva_isrip.html"
                       target="_blank">Институт социального развития и предпринимательства</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/394190_gid_po_vyzam:_kyrgyzskaia_gosydarstvennaia_medicinskaia_akademiia_imeni_i.k._ahynbaeva_kgma.html"
                       target="_blank">Кыргызская государственная медицинская академия имени И. К. Ахунбаева
                        (КГМА)</a>
                </li>
            </ul>
            <h2>Негосударственные вузы</h2>
            <p>
            <ul class="bb-list bb-list-1">
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376000_gid_po_vyzam_bishkeka:_akademiia_tyrizma.html"
                       target="_blank">Академия туризма и сервиса</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376301_gid_po_vyzam_bishkeka:_vostochnyy_yniversitet_im._mahmyda_kashgari_barskani.html"
                       target="_blank">Восточный университет им. Махмуда Кашгари-Барскани</li>
                <li>(международный Кувейтский университет)</a></li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376003_gid_po_vyzam_bishkeka:_mejdynarodnaia_akademiia_ypravleniia_prava_finansov_i_biznesa.html"
                       target="_blank">Международная академия управления, права, финансов и бизнеса</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/375709_gid_po_vyzam_bishkeka:_amerikanskiy_yniversitet_v_centralnoy_azii_ayca.html"
                       target="_blank">Американский университет в Центральной Азии</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376036_gid_po_vyzam_bishkeka:_mejdynarodnyy_yniversitet_ala_too_mya.html"
                       target="_blank">Международный университет "Ата-Тюрк Ала-Тоо"</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376054_gid_po_vyzam_bishkeka:_kyrgyzsko_kazahskiy_yniversitet_kky.html"
                       target="_blank">Кыргызско-казахский университет</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/376507_gid_po_vyzam_bishkeka:_instityt_sovremennyh_informacionnyh_tehnologiy_v_obrazovanii.html"
                       target="_blank">Институт стратегических информационных технологий в образовании</a>
                </li>
                <li><a class="bb-link"
                       href="https://kaktus.media/doc/394195_gid_po_vyzam:_kyrgyzsko_germanskiy_instityt_prikladnoy_informatiki.html"
                       target="_blank">Кыргызско-германский институт прикладной информатики</a>
                </li>
                <li><a class="bb-link" href="https://kaktus.media/doc/394192_gid_po_vyzam:_yniversitet_adam.html"
                       target="_blank">Университет
                        "Адам"</a>
                </li>
            </ul>
        </div>
    </section><!-- End Portfolio Details Section -->

</main><!-- End #main -->

<footer id="footer">

    <div class="container d-md-flex py-4">

        <div class="me-md-auto text-center text-md-start">
            <div class="copyright">
                &copy; Copyright <strong><span>VUZ.KG</span></strong>. All Rights Reserved
            </div>
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
            <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
            <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
            <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
            <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
            <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
    </div>
</footer><!-- End Footer -->

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<script src="assets/vendor/purecounter/purecounter.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

<script src="assets/js/main.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>

<script src="assets/vendor/datatables/js/dataTables.bootstrap4.min.js"></script>

<script src="assets/vendor/datatables/js/buttons.bootstrap4.min.js"></script>
<script src="assets/vendor/datatables/js/data-table.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/rowgroup/1.0.4/js/dataTables.rowGroup.min.js"></script>
<script src="https://cdn.datatables.net/select/1.2.7/js/dataTables.select.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.5/js/dataTables.fixedHeader.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>


</body>

</html>
